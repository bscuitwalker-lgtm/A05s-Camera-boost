# A05s Camera Boost

A starter Android camera app designed around the Samsung Galaxy A05s.

## Included
- Highest available rear-camera resolution request
- Quality-priority still capture
- Boost / Night / HDR / Pro UI modes
- Exposure compensation slider
- Tap-ready CameraX preview
- 4K-first video quality selection with automatic fallback
- Separate image-enhancement engine for future stronger processing
- Photos saved under `Pictures/A05s Camera Boost`

## Important hardware limitation
The app cannot change the physical camera sensor. The "50 MP" result depends on what the A05s camera HAL exposes to third-party apps. The app requests the highest available resolution rather than hard-coding an unsupported size.

Night/HDR/Pro are UI modes in v1. A true multi-frame HDR/night pipeline and full manual ISO/shutter controls require device-specific Camera2 capabilities and testing on the exact A05s firmware.

## Build
Open this folder in Android Studio and let Gradle sync. Connect the A05s with USB debugging enabled, then Run.

Recommended:
- Android Studio Ladybug or newer
- JDK 17
- Android SDK 35

## Next tuning stage
Capture sample photos in:
1. daylight
2. indoor
3. low light
4. 2x/4x digital zoom
5. backlit scene

Then compare the stock Samsung Camera output against A05s Camera Boost. The enhancement pipeline can be tuned from those samples.
