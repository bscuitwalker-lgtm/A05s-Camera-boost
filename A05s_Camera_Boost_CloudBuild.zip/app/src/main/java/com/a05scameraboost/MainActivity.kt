package com.a05scameraboost

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.MeteringPointFactory
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (!hasPermissions()) {
            requestPermissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }

        setContent { CameraBoostApp() }
    }

    private fun hasPermissions() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private val requestPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
}

@Composable
fun CameraBoostApp() {
    val context = LocalContext.current
    val previewView = remember { PreviewView(context) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var mode by remember { mutableStateOf("BOOST") }
    var ev by remember { mutableFloatStateOf(0f) }
    var message by remember { mutableStateOf("Ready") }

    LaunchedEffect(Unit) {
        val provider = ProcessCameraProvider.getInstance(context).get()
        val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }

        val selector = ResolutionSelector.Builder()
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
            .build()

        val capture = ImageCapture.Builder()
            .setResolutionSelector(selector)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()

        val recorder = Recorder.Builder()
            .setQualitySelector(
                QualitySelector.fromOrderedList(
                    listOf(Quality.UHD, Quality.FHD, Quality.HD, Quality.SD)
                )
            ).build()

        val vc = VideoCapture.withOutput(recorder)
        provider.unbindAll()
        val bound = provider.bindToLifecycle(
            context as MainActivity,
            CameraSelector.DEFAULT_BACK_CAMERA,
            preview, capture, vc
        )
        camera = bound
        imageCapture = capture
        videoCapture = vc
    }

    LaunchedEffect(ev) {
        camera?.cameraControl?.setExposureCompensationIndex(ev.toInt())
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { previewView },
            modifier = Modifier.fillMaxSize()
        )

        Column(
            Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("A05s CAMERA BOOST", color = Color.White)
                Text(message, color = Color.White)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("BOOST", "NIGHT", "HDR", "PRO").forEach { m ->
                        FilterChip(
                            selected = mode == m,
                            onClick = { mode = m },
                            label = { Text(m) }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                Text("Exposure", color = Color.White)
                Slider(
                    value = ev,
                    onValueChange = { ev = it },
                    valueRange = -3f..3f,
                    steps = 11
                )

                Button(
                    onClick = {
                        imageCapture?.let { capture ->
                            val name = "A05sBoost_" +
                                    SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) +
                                    ".jpg"
                            val values = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/A05s Camera Boost")
                            }
                            val options = ImageCapture.OutputFileOptions.Builder(
                                context.contentResolver,
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                values
                            ).build()

                            message = "Processing…"
                            capture.takePicture(
                                options,
                                ContextCompat.getMainExecutor(context),
                                object : ImageCapture.OnImageSavedCallback {
                                    override fun onImageSaved(
                                        outputFileResults: ImageCapture.OutputFileResults
                                    ) {
                                        message = "Saved • $mode"
                                    }
                                    override fun onError(exception: ImageCaptureException) {
                                        message = "Capture error"
                                    }
                                }
                            )
                        }
                    },
                    modifier = Modifier.size(88.dp)
                ) { Text("PHOTO") }

                Spacer(Modifier.height(8.dp))

                Button(onClick = {
                    val vc = videoCapture ?: return@Button
                    if (recording == null) {
                        val file = File(
                            context.cacheDir,
                            "A05sBoost_${System.currentTimeMillis()}.mp4"
                        )
                        recording = vc.output
                            .prepareRecording(context, FileOutputOptions.Builder(file).build())
                            .withAudioEnabled()
                            .start(ContextCompat.getMainExecutor(context)) { event ->
                                if (event is VideoRecordEvent.Finalize) {
                                    message = "Video saved to app cache"
                                    recording = null
                                }
                            }
                        message = "Recording…"
                    } else {
                        recording?.stop()
                        recording = null
                    }
                }) {
                    Text(if (recording == null) "VIDEO" else "STOP")
                }
            }
        }
    }
}

/**
 * Optional enhancement engine.
 *
 * This intentionally works on a decoded Bitmap rather than claiming to alter
 * the physical sensor. It is kept separate so stronger GPU/RAW processing can
 * be added later without rewriting the camera UI.
 */
object BoostProcessor {
    fun enhance(source: Bitmap, strength: Float = 0.35f): Bitmap {
        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val w = out.width
        val h = out.height
        val pixels = IntArray(w * h)
        out.getPixels(pixels, 0, w, 0, 0, w, h)

        for (i in pixels.indices) {
            val c = pixels[i]
            var r = (c shr 16) and 255
            var g = (c shr 8) and 255
            var b = c and 255

            // Gentle contrast and highlight-safe saturation lift.
            fun lift(v: Int): Int {
                val x = v / 255f
                val y = ((x - 0.5f) * (1f + 0.22f * strength)) + 0.5f
                return (y * 255f).coerceIn(0f, 255f).toInt()
            }
            r = lift(r); g = lift(g); b = lift(b)

            pixels[i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
        }
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }
}
